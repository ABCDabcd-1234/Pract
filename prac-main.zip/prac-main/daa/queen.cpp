#include<bits/stdc++.h>
using namespace std;

const int N = 8;
int board[N][N];

void printBoard(){
    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++){
            cout << board[i][j] << " ";
        }
        cout << '\n';
    }
}


bool isSafe(int row, int col){
    int i, j;

    // check column above this row
    for(i = 0; i < row; i++){
        if(board[i][col]) return false;
    }

    // check upper-left diagonal
    for(i = row, j = col; i >= 0 && j >= 0; i--, j--){
        if(board[i][j]) return false;
    }

    // check upper-right diagonal
    for(i = row, j = col; i >= 0 && j < N; i--, j++){
        if(board[i][j]) return false;
    }

    return true;
}

bool solveNQ(int row, int fixedRow, int fixedCol){
    if(row >= N) return true; // all queeens are placed

    if(row == fixedRow){
        return solveNQ(row+1, fixedRow, fixedCol);
    }

    for(int col = 0; col < N; col++){
        if(isSafe(row, col)){
            board[row][col] = 1;

            if(solveNQ(row +1, fixedRow, fixedCol)) return true;

            board[row][col] = 0;
        }
    }
    
    return false;
}


int main(){
    memset(board, 0, sizeof(board));

    int row, col;
    cout << "Enter the position of first queen (row, col) 0 - based index: " << '\n';
    cin >> row >> col;

    board[row][col] = 1;

    if(solveNQ(0, row, col)){
        cout << "\n Final 8-Queens Solution: \n";
        printBoard();
    }
    else{
        cout << "No Solution exists \n";
    }


    return 0;
}