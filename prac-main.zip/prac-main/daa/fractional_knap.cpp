#include<bits/stdc++.h>
using namespace std;

struct Item{
    int value, weight;

    Item(int v, int w){
        value = v;
        weight = w;
    }
};


double fractionalKnapsack(int W, vector<Item> &items){
    sort(items.begin(), items.end(), [&](struct Item a, struct Item b){
        double r1 = (double)a.value / a.weight;
        double r2 = (double)b.value / b.weight;
        return r1 > r2;
    });

    double totalValue = 0.0;
    int currWeight = 0;

    for(auto &item : items){
        if(currWeight + item.weight <= W){
            // take full item.
            currWeight += item.weight;
            totalValue += item.value;
        }
        else{
            int remain = W - currWeight;
            totalValue += item.value * ((double)remain / item.weight);
            break;
        }
    }

    return totalValue;
}


int main(){
    int n, W;
    cout << "Enter number of items: ";
    cin >> n;

    vector<Item>items;
    cout << "Enter value and weight of each item: \n";

    for(int i = 0; i < n; i++){
        int value, weight;
        cin >> value >> weight;
        items.push_back(Item(value, weight));
    }

    cout << "Enter capacity of knapsack: " ;
    cin >> W;

    double maxValue = fractionalKnapsack(W, items);
    cout << fixed << setprecision(2);
    cout << "\nMaximum value in knapsack = " << maxValue << '\n';


    return 0;
}



/*
Enter number of items: 3
Enter value and weight of each item: 
60 10
100 20
120 30
Enter capacity of knapsack: 50

Maximum value in knapsack = 240.00
*/