

# Import libraries
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from scipy.cluster.hierarchy import dendrogram, linkage, fcluster

# Load dataset
data = pd.read_csv("sales_data_sample.csv", encoding='latin1')
print("Initial shape:", data.shape)
print(data.head())

# Data preprocessing — selecting numeric columns
numeric_data = data.select_dtypes(include=['int64', 'float64']).copy()
numeric_data = numeric_data.dropna()

print("\nNumeric columns used for clustering:")
print(numeric_data.columns.tolist())

# Normalize the data
scaler = StandardScaler()
scaled_data = scaler.fit_transform(numeric_data)


# K-MEANS CLUSTERING

# Finding optimal number of clusters using Elbow Method
inertia = []
K = range(2, 10)

for k in K:
    model = KMeans(n_clusters=k, random_state=42)
    model.fit(scaled_data)
    inertia.append(model.inertia_)

plt.figure(figsize=(6,4))
plt.plot(K, inertia, 'bo-')
plt.xlabel('Number of clusters (k)')
plt.ylabel('Inertia')
plt.title('Elbow Method For Optimal k')
plt.show()

# Choose k=3
kmeans = KMeans(n_clusters=3, random_state=42)
clusters = kmeans.fit_predict(scaled_data)
numeric_data['Cluster'] = clusters

# Visualize first two features
plt.figure(figsize=(6,4))
plt.scatter(scaled_data[:, 0], scaled_data[:, 1], c=clusters, cmap='viridis')
plt.title('K-Means Clustering Visualization')
plt.xlabel(numeric_data.columns[0])
plt.ylabel(numeric_data.columns[1])
plt.show()

# Cluster summary
cluster_summary = numeric_data.groupby('Cluster').mean()
print("\nCluster summary:")
print(cluster_summary)