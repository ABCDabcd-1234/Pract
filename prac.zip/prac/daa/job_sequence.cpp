#include<bits/stdc++.h>
using namespace std;


struct Job{
    char id;
    int deadline;
    int profit;
};

// The goal is to schedule jobs to maximize total profit, ensuring that no two jobs overlap (only one job can be done at a time).

int main(){
    int n;
    cout << "Enter number of jobs" << '\n';
    cin >> n;

    vector<Job> jobs(n);
    cout << "Enter job id, deadline and profit for each job" << '\n';
    
    for(int i = 0; i < n; i++){
        cin >> jobs[i].id >> jobs[i].deadline >> jobs[i].profit;
    }

    // sort jobs based on profit in descending
    sort(jobs.begin(), jobs.end(), [&](Job &a, Job &b){
        return a.profit > b.profit;
    });


    int maxDeadline = 0;
    for(auto &job : jobs){
        maxDeadline = max(maxDeadline, job.deadline);
    }

    vector<char>slot(maxDeadline +1, '-');
    int total_profit = 0;

    for(int i = 0; i < n; i++){
        for(int j = jobs[i].deadline; j > 0; j--){
            if(slot[j] == '-'){
                slot[j] = jobs[i].id;
                total_profit += jobs[i].profit;
                break;
            }
        }
    }

    cout << "\nScheduled Jobs: ";
    for(int i = 1; i <= maxDeadline; i++){
        if(slot[i] != '-'){
            cout << slot[i] << " ";
        }
    }

    cout << "\nTotal Profit: " << total_profit << '\n';


    return 0;
}

/*
Enter number of jobs: 5
Enter job id, deadline, and profit for each job:
A 2 100
B 1 19
C 2 27
D 1 25
E 3 15


Scheduled Jobs: C A E
Total Profit: 142

*/


