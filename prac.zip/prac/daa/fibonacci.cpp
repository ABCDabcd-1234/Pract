#include<bits/stdc++.h>
using namespace std;

int stepCount = 0;

int fibonacci(int n){
    stepCount++;
    if(n <= 1){
        return n;
    }
    return fibonacci(n-1) + fibonacci(n-2);
}

int main(){
    int n; cin >> n;
    cout << fibonacci(n) << '\n';
    cout << stepCount << '\n';

    return 0;
}