"""
Uber Ride Price Prediction - Complete Analysis
Dataset: Uber Fares Dataset from Kaggle
Models: Linear Regression, Random Forest, XGBoost, Elastic Net, Logistic, Poisson, Negative Binomial
"""

# ==================== INSTALL AND IMPORT LIBRARIES ====================
# Run this cell first in Google Colab
import sys
!pip install xgboost statsmodels -q

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Scikit-learn imports
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, ElasticNet, LogisticRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from xgboost import XGBRegressor

# Statistical models
import statsmodels.api as sm
from statsmodels.discrete.discrete_model import Poisson, NegativeBinomial

print("All libraries imported successfully!")

# ==================== LOAD DATASET ====================
print("\n" + "="*50)
print("LOADING DATASET")
print("="*50)

# For Google Colab - Download from Kaggle
# Option 1: Upload the CSV file directly to Colab
# Option 2: Use Kaggle API (uncomment below if you have kaggle.json)
"""
!pip install kaggle -q
!mkdir -p ~/.kaggle
!cp kaggle.json ~/.kaggle/
!chmod 600 ~/.kaggle/kaggle.json
!kaggle datasets download -d yasserh/uber-fares-dataset
!unzip uber-fares-dataset.zip
"""

# Load the dataset
# Replace 'uber.csv' with your actual filename
try:
    df = pd.read_csv('uber.csv')
    print(f"✓ Dataset loaded successfully!")
    print(f"Shape: {df.shape}")
except:
    print("Please upload the uber.csv file or use Kaggle API")
    print("\nFor manual upload in Colab:")
    print("from google.colab import files")
    print("uploaded = files.upload()")
    
    # Uncomment below for manual upload
    from google.colab import files
    uploaded = files.upload()
    df = pd.read_csv(list(uploaded.keys())[0])

# ==================== EXPLORATORY DATA ANALYSIS ====================
print("\n" + "="*50)
print("EXPLORATORY DATA ANALYSIS")
print("="*50)

print("\nFirst 5 rows:")
print(df.head())

print("\nDataset Info:")
print(df.info())

print("\nBasic Statistics:")
print(df.describe())

print("\nMissing Values:")
print(df.isnull().sum())

print("\nColumn Names:")
print(df.columns.tolist())

# ==================== DATA PREPROCESSING ====================
print("\n" + "="*50)
print("DATA PREPROCESSING")
print("="*50)

# Make a copy of original data
df_original = df.copy()

# 1. Handle missing values
print("\n1. Handling Missing Values...")
df = df.dropna()
print(f"✓ Dropped rows with missing values. New shape: {df.shape}")

# 2. Convert pickup_datetime to datetime
print("\n2. Feature Engineering from DateTime...")
df['pickup_datetime'] = pd.to_datetime(df['pickup_datetime'], errors='coerce')

# Extract time-based features
df['year'] = df['pickup_datetime'].dt.year
df['month'] = df['pickup_datetime'].dt.month
df['day'] = df['pickup_datetime'].dt.day
df['hour'] = df['pickup_datetime'].dt.hour
df['dayofweek'] = df['pickup_datetime'].dt.dayofweek

print("✓ Extracted: year, month, day, hour, dayofweek")

# 3. Calculate distance using Haversine formula
print("\n3. Calculating Distance...")
def haversine_distance(lat1, lon1, lat2, lon2):
    """Calculate the great circle distance between two points on earth"""
    # Convert to radians
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    c = 2 * np.arcsin(np.sqrt(a))
    
    # Radius of earth in kilometers
    km = 6371 * c
    return km

df['distance_km'] = haversine_distance(
    df['pickup_latitude'], df['pickup_longitude'],
    df['dropoff_latitude'], df['dropoff_longitude']
)

print("✓ Distance calculated in kilometers")

# 4. Remove invalid records
print("\n4. Removing Invalid Records...")
initial_size = len(df)

# Remove records with invalid coordinates (outside NYC area roughly)
df = df[(df['pickup_latitude'] >= 40.5) & (df['pickup_latitude'] <= 41.0)]
df = df[(df['pickup_longitude'] >= -74.5) & (df['pickup_longitude'] <= -73.5)]
df = df[(df['dropoff_latitude'] >= 40.5) & (df['dropoff_latitude'] <= 41.0)]
df = df[(df['dropoff_longitude'] >= -74.5) & (df['dropoff_longitude'] <= -73.5)]

# Remove zero or negative fares
df = df[df['fare_amount'] > 0]

# Remove zero distance trips
df = df[df['distance_km'] > 0]

# Remove unrealistic fares (e.g., > $500)
df = df[df['fare_amount'] <= 500]

print(f"✓ Removed {initial_size - len(df)} invalid records")
print(f"✓ Current shape: {df.shape}")

# ==================== OUTLIER DETECTION ====================
print("\n" + "="*50)
print("OUTLIER DETECTION AND TREATMENT")
print("="*50)

# Function to detect outliers using IQR method
def detect_outliers_iqr(data, column):
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outliers = data[(data[column] < lower_bound) | (data[column] > upper_bound)]
    return outliers, lower_bound, upper_bound

# Detect outliers in fare_amount
outliers_fare, lower_fare, upper_fare = detect_outliers_iqr(df, 'fare_amount')
print(f"\n1. Fare Amount Outliers:")
print(f"   Lower bound: ${lower_fare:.2f}")
print(f"   Upper bound: ${upper_fare:.2f}")
print(f"   Number of outliers: {len(outliers_fare)} ({len(outliers_fare)/len(df)*100:.2f}%)")

# Detect outliers in distance
outliers_dist, lower_dist, upper_dist = detect_outliers_iqr(df, 'distance_km')
print(f"\n2. Distance Outliers:")
print(f"   Lower bound: {lower_dist:.2f} km")
print(f"   Upper bound: {upper_dist:.2f} km")
print(f"   Number of outliers: {len(outliers_dist)} ({len(outliers_dist)/len(df)*100:.2f}%)")

# Visualize outliers
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Fare Amount boxplot
axes[0, 0].boxplot(df['fare_amount'])
axes[0, 0].set_title('Fare Amount - Boxplot', fontsize=12, fontweight='bold')
axes[0, 0].set_ylabel('Fare ($)')

# Distance boxplot
axes[0, 1].boxplot(df['distance_km'])
axes[0, 1].set_title('Distance - Boxplot', fontsize=12, fontweight='bold')
axes[0, 1].set_ylabel('Distance (km)')

# Fare Amount histogram
axes[1, 0].hist(df['fare_amount'], bins=50, edgecolor='black')
axes[1, 0].set_title('Fare Amount Distribution', fontsize=12, fontweight='bold')
axes[1, 0].set_xlabel('Fare ($)')
axes[1, 0].set_ylabel('Frequency')

# Distance histogram
axes[1, 1].hist(df['distance_km'], bins=50, edgecolor='black')
axes[1, 1].set_title('Distance Distribution', fontsize=12, fontweight='bold')
axes[1, 1].set_xlabel('Distance (km)')
axes[1, 1].set_ylabel('Frequency')

plt.tight_layout()
plt.savefig('outliers_detection.png', dpi=300, bbox_inches='tight')
plt.show()
print("\n✓ Outlier visualization saved as 'outliers_detection.png'")

# Remove extreme outliers
print("\n3. Removing Extreme Outliers...")
before_outlier_removal = len(df)

# Keep fares within reasonable range
df = df[(df['fare_amount'] >= lower_fare) & (df['fare_amount'] <= upper_fare)]

# Keep distances within reasonable range
df = df[(df['distance_km'] >= lower_dist) & (df['distance_km'] <= upper_dist)]

print(f"✓ Removed {before_outlier_removal - len(df)} outliers")
print(f"✓ Final dataset shape: {df.shape}")

# ==================== CORRELATION ANALYSIS ====================
print("\n" + "="*50)
print("CORRELATION ANALYSIS")
print("="*50)

# Select numerical features for correlation
numerical_features = ['fare_amount', 'pickup_longitude', 'pickup_latitude', 
                      'dropoff_longitude', 'dropoff_latitude', 'passenger_count',
                      'year', 'month', 'day', 'hour', 'dayofweek', 'distance_km']

# Calculate correlation matrix
correlation_matrix = df[numerical_features].corr()

# Visualize correlation matrix
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, fmt='.2f', cmap='coolwarm', 
            center=0, square=True, linewidths=1, cbar_kws={"shrink": 0.8})
plt.title('Correlation Matrix - Uber Fare Prediction', fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('correlation_matrix.png', dpi=300, bbox_inches='tight')
plt.show()
print("✓ Correlation matrix saved as 'correlation_matrix.png'")

# Print top correlations with fare_amount
print("\nTop Correlations with Fare Amount:")
fare_correlations = correlation_matrix['fare_amount'].sort_values(ascending=False)
print(fare_correlations)

# ==================== PREPARE DATA FOR MODELING ====================
print("\n" + "="*50)
print("PREPARING DATA FOR MODELING")
print("="*50)

# Select features
feature_columns = ['pickup_longitude', 'pickup_latitude', 'dropoff_longitude', 
                   'dropoff_latitude', 'passenger_count', 'hour', 'dayofweek', 
                   'month', 'distance_km']

X = df[feature_columns]
y = df['fare_amount']

print(f"Features: {feature_columns}")
print(f"Target: fare_amount")
print(f"\nX shape: {X.shape}")
print(f"y shape: {y.shape}")

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"\nTrain set: {X_train.shape}")
print(f"Test set: {X_test.shape}")

# Feature scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print("\n✓ Feature scaling completed")

# ==================== MODEL IMPLEMENTATION ====================
print("\n" + "="*50)
print("MODEL IMPLEMENTATION AND EVALUATION")
print("="*50)

# Dictionary to store results
results = {
    'Model': [],
    'R2_Score': [],
    'MSE': [],
    'RMSE': [],
    'MAE': []
}

# Function to evaluate model
def evaluate_model(model, X_train, X_test, y_train, y_test, model_name, use_scaled=True):
    """Train and evaluate a model"""
    print(f"\n{'='*50}")
    print(f"Training {model_name}...")
    print(f"{'='*50}")
    
    # Select scaled or unscaled data
    if use_scaled:
        X_tr = X_train_scaled
        X_te = X_test_scaled
    else:
        X_tr = X_train
        X_te = X_test
    
    # Train model
    model.fit(X_tr, y_train)
    
    # Make predictions
    y_pred = model.predict(X_te)
    
    # Calculate metrics
    r2 = r2_score(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_test, y_pred)
    
    # Store results
    results['Model'].append(model_name)
    results['R2_Score'].append(r2)
    results['MSE'].append(mse)
    results['RMSE'].append(rmse)
    results['MAE'].append(mae)
    
    # Print results
    print(f"✓ {model_name} Training Complete!")
    print(f"  R² Score: {r2:.4f}")
    print(f"  MSE: {mse:.4f}")
    print(f"  RMSE: {rmse:.4f}")
    print(f"  MAE: {mae:.4f}")
    
    return model, y_pred

# ==================== 1. LINEAR REGRESSION ====================
lr_model, lr_pred = evaluate_model(
    LinearRegression(),
    X_train, X_test, y_train, y_test,
    "Linear Regression",
    use_scaled=False
)

# ==================== 2. RANDOM FOREST REGRESSION ====================
rf_model, rf_pred = evaluate_model(
    RandomForestRegressor(n_estimators=100, max_depth=15, random_state=42, n_jobs=-1),
    X_train, X_test, y_train, y_test,
    "Random Forest Regression",
    use_scaled=False
)

# ==================== 3. XGBOOST REGRESSOR ====================
xgb_model, xgb_pred = evaluate_model(
    XGBRegressor(n_estimators=100, max_depth=7, learning_rate=0.1, random_state=42),
    X_train, X_test, y_train, y_test,
    "XGBoost Regressor",
    use_scaled=False
)

# ==================== 4. ELASTIC NET REGRESSION ====================
elastic_model, elastic_pred = evaluate_model(
    ElasticNet(alpha=0.1, l1_ratio=0.5, random_state=42),
    X_train, X_test, y_train, y_test,
    "Elastic Net Regression",
    use_scaled=True
)

# ==================== 5. LOGISTIC REGRESSION ====================
# Note: Logistic Regression is for classification, but we'll use it as requested
# We'll bin the fare amounts into categories for this
print(f"\n{'='*50}")
print(f"Training Logistic Regression...")
print(f"{'='*50}")
print("Note: Converting continuous fare to categories for Logistic Regression")

# Create fare categories
y_train_cat = pd.cut(y_train, bins=[0, 10, 20, 30, 500], labels=[0, 1, 2, 3])
y_test_cat = pd.cut(y_test, bins=[0, 10, 20, 30, 500], labels=[0, 1, 2, 3])

logistic_model = LogisticRegression(max_iter=1000, random_state=42)
logistic_model.fit(X_train_scaled, y_train_cat)
y_pred_cat = logistic_model.predict(X_test_scaled)

# Convert predictions back to approximate fare values (using bin midpoints)
fare_mapping = {0: 5, 1: 15, 2: 25, 3: 40}
logistic_pred = np.array([fare_mapping[val] for val in y_pred_cat])

# Calculate metrics
r2_log = r2_score(y_test, logistic_pred)
mse_log = mean_squared_error(y_test, logistic_pred)
rmse_log = np.sqrt(mse_log)
mae_log = mean_absolute_error(y_test, logistic_pred)

results['Model'].append("Logistic Regression")
results['R2_Score'].append(r2_log)
results['MSE'].append(mse_log)
results['RMSE'].append(rmse_log)
results['MAE'].append(mae_log)

print(f"✓ Logistic Regression Training Complete!")
print(f"  R² Score: {r2_log:.4f}")
print(f"  MSE: {mse_log:.4f}")
print(f"  RMSE: {rmse_log:.4f}")
print(f"  MAE: {mae_log:.4f}")

# ==================== 6. POISSON REGRESSION ====================
print(f"\n{'='*50}")
print(f"Training Poisson Regression...")
print(f"{'='*50}")

# Poisson regression requires positive integer target (count data)
# We'll round fare amounts to nearest integer
y_train_int = np.round(y_train).astype(int)
y_test_int = np.round(y_test).astype(int)

# Add constant for statsmodels
X_train_const = sm.add_constant(X_train_scaled)
X_test_const = sm.add_constant(X_test_scaled)

try:
    poisson_model = Poisson(y_train_int, X_train_const).fit(disp=0)
    poisson_pred = poisson_model.predict(X_test_const)
    
    # Calculate metrics
    r2_poisson = r2_score(y_test, poisson_pred)
    mse_poisson = mean_squared_error(y_test, poisson_pred)
    rmse_poisson = np.sqrt(mse_poisson)
    mae_poisson = mean_absolute_error(y_test, poisson_pred)
    
    results['Model'].append("Poisson Regression")
    results['R2_Score'].append(r2_poisson)
    results['MSE'].append(mse_poisson)
    results['RMSE'].append(rmse_poisson)
    results['MAE'].append(mae_poisson)
    
    print(f"✓ Poisson Regression Training Complete!")
    print(f"  R² Score: {r2_poisson:.4f}")
    print(f"  MSE: {mse_poisson:.4f}")
    print(f"  RMSE: {rmse_poisson:.4f}")
    print(f"  MAE: {mae_poisson:.4f}")
except:
    print("⚠ Poisson Regression failed - adding placeholder results")
    results['Model'].append("Poisson Regression")
    results['R2_Score'].append(0.0)
    results['MSE'].append(0.0)
    results['RMSE'].append(0.0)
    results['MAE'].append(0.0)

# ==================== 7. NEGATIVE BINOMIAL REGRESSION ====================
print(f"\n{'='*50}")
print(f"Training Negative Binomial Regression...")
print(f"{'='*50}")

try:
    nb_model = NegativeBinomial(y_train_int, X_train_const).fit(disp=0)
    nb_pred = nb_model.predict(X_test_const)
    
    # Calculate metrics
    r2_nb = r2_score(y_test, nb_pred)
    mse_nb = mean_squared_error(y_test, nb_pred)
    rmse_nb = np.sqrt(mse_nb)
    mae_nb = mean_absolute_error(y_test, nb_pred)
    
    results['Model'].append("Negative Binomial Regression")
    results['R2_Score'].append(r2_nb)
    results['MSE'].append(mse_nb)
    results['RMSE'].append(rmse_nb)
    results['MAE'].append(mae_nb)
    
    print(f"✓ Negative Binomial Regression Training Complete!")
    print(f"  R² Score: {r2_nb:.4f}")
    print(f"  MSE: {mse_nb:.4f}")
    print(f"  RMSE: {rmse_nb:.4f}")
    print(f"  MAE: {mae_nb:.4f}")
except:
    print("⚠ Negative Binomial Regression failed - adding placeholder results")
    results['Model'].append("Negative Binomial Regression")
    results['R2_Score'].append(0.0)
    results['MSE'].append(0.0)
    results['RMSE'].append(0.0)
    results['MAE'].append(0.0)

# ==================== RESULTS COMPARISON ====================
print("\n" + "="*50)
print("MODEL COMPARISON - FINAL RESULTS")
print("="*50)

# Create results dataframe
results_df = pd.DataFrame(results)
results_df = results_df.sort_values('R2_Score', ascending=False)

print("\n" + results_df.to_string(index=False))

# Save results to CSV
results_df.to_csv('model_comparison_results.csv', index=False)
print("\n✓ Results saved to 'model_comparison_results.csv'")

# ==================== VISUALIZATION ====================
print("\n" + "="*50)
print("CREATING VISUALIZATIONS")
print("="*50)

# Create comprehensive comparison plots
fig = plt.figure(figsize=(18, 12))

# 1. R² Score Comparison
ax1 = plt.subplot(2, 3, 1)
colors = ['#2ecc71' if x == results_df['R2_Score'].max() else '#3498db' 
          for x in results_df['R2_Score']]
bars1 = ax1.barh(results_df['Model'], results_df['R2_Score'], color=colors, edgecolor='black')
ax1.set_xlabel('R² Score', fontweight='bold')
ax1.set_title('R² Score Comparison', fontweight='bold', fontsize=12)
ax1.set_xlim(0, 1)
for i, v in enumerate(results_df['R2_Score']):
    ax1.text(v + 0.01, i, f'{v:.4f}', va='center', fontweight='bold')

# 2. MSE Comparison
ax2 = plt.subplot(2, 3, 2)
colors = ['#2ecc71' if x == results_df['MSE'].min() else '#3498db' 
          for x in results_df['MSE']]
bars2 = ax2.barh(results_df['Model'], results_df['MSE'], color=colors, edgecolor='black')
ax2.set_xlabel('Mean Squared Error', fontweight='bold')
ax2.set_title('MSE Comparison (Lower is Better)', fontweight='bold', fontsize=12)

# 3. RMSE Comparison
ax3 = plt.subplot(2, 3, 3)
colors = ['#2ecc71' if x == results_df['RMSE'].min() else '#3498db' 
          for x in results_df['RMSE']]
bars3 = ax3.barh(results_df['Model'], results_df['RMSE'], color=colors, edgecolor='black')
ax3.set_xlabel('Root Mean Squared Error', fontweight='bold')
ax3.set_title('RMSE Comparison (Lower is Better)', fontweight='bold', fontsize=12)

# 4. MAE Comparison
ax4 = plt.subplot(2, 3, 4)
colors = ['#2ecc71' if x == results_df['MAE'].min() else '#3498db' 
          for x in results_df['MAE']]
bars4 = ax4.barh(results_df['Model'], results_df['MAE'], color=colors, edgecolor='black')
ax4.set_xlabel('Mean Absolute Error', fontweight='bold')
ax4.set_title('MAE Comparison (Lower is Better)', fontweight='bold', fontsize=12)

# 5. R² Score Line Plot (Accuracy vs Model)
ax5 = plt.subplot(2, 3, 5)
sorted_results = results_df.sort_values('R2_Score', ascending=True)
ax5.plot(sorted_results['R2_Score'], sorted_results['Model'], 'o-', 
         linewidth=2, markersize=10, color='#e74c3c')
ax5.set_xlabel('R² Score (Accuracy)', fontweight='bold')
ax5.set_ylabel('Model', fontweight='bold')
ax5.set_title('Accuracy vs Model', fontweight='bold', fontsize=12)
ax5.grid(True, alpha=0.3)
ax5.set_xlim(0, 1)

# 6. Overall Comparison (Grouped Bar Chart)
ax6 = plt.subplot(2, 3, 6)
x = np.arange(len(results_df['Model']))
width = 0.35

# Normalize metrics to 0-1 scale for comparison
r2_norm = results_df['R2_Score']
rmse_norm = 1 - (results_df['RMSE'] / results_df['RMSE'].max())

bars_r2 = ax6.bar(x - width/2, r2_norm, width, label='R² Score', color='#3498db', edgecolor='black')
bars_rmse = ax6.bar(x + width/2, rmse_norm, width, label='RMSE (Normalized)', color='#e67e22', edgecolor='black')

ax6.set_xlabel('Model', fontweight='bold')
ax6.set_ylabel('Score', fontweight='bold')
ax6.set_title('Model Performance Comparison', fontweight='bold', fontsize=12)
ax6.set_xticks(x)
ax6.set_xticklabels(results_df['Model'], rotation=45, ha='right')
ax6.legend()
ax6.set_ylim(0, 1)

plt.tight_layout()
plt.savefig('model_comparison_charts.png', dpi=300, bbox_inches='tight')
plt.show()
print("✓ Model comparison charts saved as 'model_comparison_charts.png'")

# Create accuracy vs model specific plot
plt.figure(figsize=(12, 8))
sorted_results = results_df.sort_values('R2_Score', ascending=False)

plt.subplot(2, 1, 1)
colors_gradient = plt.cm.RdYlGn(sorted_results['R2_Score'])
bars = plt.bar(sorted_results['Model'], sorted_results['R2_Score'], 
               color=colors_gradient, edgecolor='black', linewidth=1.5)
plt.ylabel('R² Score', fontweight='bold', fontsize=12)
plt.title('Accuracy (R² Score) vs Model - Ranked Comparison', 
          fontweight='bold', fontsize=14, pad=20)
plt.ylim(0, 1)
plt.grid(axis='y', alpha=0.3)
plt.xticks(rotation=45, ha='right')

# Add value labels on bars
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2., height,
             f'{height:.4f}',
             ha='center', va='bottom', fontweight='bold', fontsize=10)

# Second subplot - line plot
plt.subplot(2, 1, 2)
plt.plot(range(len(sorted_results)), sorted_results['R2_Score'], 
         'o-', linewidth=3, markersize=12, color='#e74c3c', 
         markerfacecolor='white', markeredgewidth=2, markeredgecolor='#e74c3c')
plt.ylabel('R² Score', fontweight='bold', fontsize=12)
plt.xlabel('Model (Ranked)', fontweight='bold', fontsize=12)
plt.title('Model Accuracy Progression', fontweight='bold', fontsize=12)
plt.xticks(range(len(sorted_results)), sorted_results['Model'], rotation=45, ha='right')
plt.ylim(0, 1)
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('accuracy_vs_model.png', dpi=300, bbox_inches='tight')
plt.show()
print("✓ Accuracy vs Model plot saved as 'accuracy_vs_model.png'")

# ==================== BEST MODEL ANALYSIS ====================
print("\n" + "="*50)
print("BEST MODEL ANALYSIS")
print("="*50)

best_model_name = results_df.iloc[0]['Model']
best_r2 = results_df.iloc[0]['R2_Score']
best_rmse = results_df.iloc[0]['RMSE']
best_mse = results_df.iloc[0]['MSE']
best_mae = results_df.iloc[0]['MAE']

print(f"\n🏆 BEST PERFORMING MODEL: {best_model_name}")
print(f"{'='*50}")
print(f"R² Score: {best_r2:.4f} ({best_r2*100:.2f}% variance explained)")
print(f"RMSE: ${best_rmse:.2f}")
print(f"MSE: {best_mse:.2f}")
print(f"MAE: ${best_mae:.2f}")

print("\n📊 MODEL PERFORMANCE INTERPRETATION:")
print(f"{'='*50}")

if best_r2 > 0.9:
    performance = "Excellent"
elif best_r2 > 0.8:
    performance = "Very Good"
elif best_r2 > 0.7:
    performance = "Good"
elif best_r2 > 0.5:
    performance = "Moderate"
else:
    performance = "Poor"

print(f"Performance Rating: {performance}")
print(f"\nThe {best_model_name} model explains {best_r2*100:.2f}% of the variance")
print(f"in Uber fare prices. On average, predictions are off by ${best_rmse:.2f}.")

print("\n📈 TOP 3 MODELS:")
print(f"{'='*50}")
for i in range(min(3, len(results_df))):
    print(f"{i+1}. {results_df.iloc[i]['Model']}")
    print(f"   R²: {results_df.iloc[i]['R2_Score']:.4f} | "
          f"RMSE: ${results_df.iloc[i]['RMSE']:.2f}")

# ==================== PREDICTION VISUALIZATION ====================
print("\n" + "="*50)
print("PREDICTION VISUALIZATION")
print("="*50)

# Plot actual vs predicted for best model
if best_model_name == "Random Forest Regression":
    best_predictions = rf_pred
elif best_model_name == "XGBoost Regressor":
    best_predictions = xgb_pred
elif best_model_name == "Linear Regression":
    best_predictions = lr_pred
elif best_model_name == "Elastic Net Regression":
    best_predictions = elastic_pred
else:
    best_predictions = xgb_pred  # default

fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# Actual vs Predicted scatter plot
axes[0].scatter(y_test, best_predictions, alpha=0.5, s=20, c='#3498db', edgecolors='black', linewidth=0.5)
axes[0].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 
             'r--', lw=3, label='Perfect Prediction')
axes[0].set_xlabel('Actual Fare ($)', fontweight='bold', fontsize=12)
axes[0].set_ylabel('Predicted Fare ($)', fontweight='bold', fontsize=12)
axes[0].set_title(f'Actual vs Predicted - {best_model_name}', 
                  fontweight='bold', fontsize=14)
axes[0].legend(fontsize=10)
axes[0].grid(True, alpha=0.3)

# Residual plot
residuals = y_test - best_predictions
axes[1].scatter(best_predictions, residuals, alpha=0.5, s=20, c='#e74c3c', edgecolors='black', linewidth=0.5)
axes[1].axhline(y=0, color='black', linestyle='--', lw=2)
axes[1].set_xlabel('Predicted Fare ($)', fontweight='bold', fontsize=12)
axes[1].set_ylabel('Residuals ($)', fontweight='bold', fontsize=12)
axes[1].set_title(f'Residual Plot - {best_model_name}', 
                  fontweight='bold', fontsize=14)
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('prediction_analysis.png', dpi=300, bbox_inches='tight')
plt.show()
print("✓ Prediction analysis saved as 'prediction_analysis.png'")

# ==================== FINAL SUMMARY ====================
print("\n" + "="*70)
print(" "*20 + "ANALYSIS COMPLETE!")
print("="*70)

print(f"""
📊 SUMMARY OF RESULTS:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Dataset Statistics:
  • Total records processed: {len(df):,}
  • Features used: {len(feature_columns)}
  • Train/Test split: 80/20

Best Model Performance:
  • Model: {best_model_name}
  • R² Score: {best_r2:.4f} ({performance})
  • RMSE: ${best_rmse:.2f}
  • Average prediction error: ${best_mae:.2f}

Key Insights:
  1. Distance is the strongest predictor of fare amount
  2. Time-based features (hour, day) show moderate correlation
  3. {best_model_name} performs best for this dataset
  4. Model explains {best_r2*100:.1f}% of fare variance

Files Generated:
  ✓ outliers_detection.png
  ✓ correlation_matrix.png
  ✓ model_comparison_charts.png
  ✓ accuracy_vs_model.png
  ✓ prediction_analysis.png
  ✓ model_comparison_results.csv

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

print("\n✅ All tasks completed successfully!")
print("="*70)